<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemNotification extends Model
{
	protected $table="system_messages";
    //
}
