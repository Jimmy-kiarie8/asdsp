
<footer id="footer"  >


    <div class="container d-md-flex py-4" >

        <div class="mr-md-auto text-center text-md-left">
            <div class="copyright">
                &copy; <strong><span> Agricultural Sector Development Support Programme (ASDSP II)</span></strong>. All Rights Reserved
            </div>
            <div class="credits">
             
                Developed By <a href="kilimo.go.ke" style="color: #fff" class="jtl-clh">ICT Department,MALFC</a>
            </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
            <a href="https://asdsp.kilimo.go.ke" class="twitter" target="_blank"><i class="bx bxl-twitter"></i></a>
            <a href="https://asdsp.kilimo.go.ke" class="facebook" target="_blank"><i class="bx bxl-facebook"></i></a>
            <a href="https://asdsp.kilimo.go.ke" class="instagram" target="_blank"><i class="bx bxl-instagram"></i></a>
            <a href="https://asdsp.kilimo.go.ke" class="google-plus" target="_blank"><i class="bx bxl-youtube"></i></a>

        </div>
        
        <div class="mr-md-auto text-center text-md-right pt-1 pt-md-0" style="padding-left: 20px">
             <div style="text-align: left">
                <a href="#" class="jtl-clh" style="color: #fff;font-size:medium;"><strong><span>Terms and Conditions</span></strong></a>

                  
            </div>
            <div style="text-align: left">

                <a href="{{ url('') }}" class="jtl-clh" style="color: #fff;font-size:medium;"><strong><span>Contact us</span></strong></a>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->
