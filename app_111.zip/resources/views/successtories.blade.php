@extends('front.main')
<?php 
use App\Helpers\Helper; 
?>
@section('breadcrum')
<div class="row">
    <ul class="breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            
            <li class="active">Success Story</li>
        </ul>
    
</div>



@stop
@section('content')
fghgfff


@stop