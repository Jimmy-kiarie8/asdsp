<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered">
		<tr>
			<th>Name</th>
			<td>{{$member->member_name}}</td>
		</tr>
		<tr>
			<th>Telephone</th>
			<td>{{$member->member_telephone}}</td>
		</tr>

		<tr>
			<th>Location</th>
			<td>{{$member->location}}</td>
		</tr>
		

	</table>
		
	</div>
	
	
</div>