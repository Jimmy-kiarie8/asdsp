<!-- BEGIN #footer -->

<div id="footer" class="footer">

<div class="container">

<div class="row">

<div class="col-lg-3">
<h4 class="footer-header">ABOUT US</h4>
<p>
ASDSP II E-Commerce  is an online shop for value chain actors to market their products at free of charge.It enables buyers to get access to products at a mouce click unlike the traditional methods.
</p>
<p class="mb-lg-4 mb-0">
For Value Chain Actor to be able to market their product,they must be registed under a VCO then given unique identifier.
</p>
</div>


<div class="col-lg-3">
<h4 class="footer-header">Value Chains</h4>
<ul class="fa-ul mb-lg-4 mb-0 p-0">
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Banana</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Cow Milk</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Fish</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Maize</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Meat Goat</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Indigenous Chicken</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Sorghum</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Cassava</a></li>
</ul>
</div>


<div class="col-lg-3">
<h4 class="footer-header"></h4><br>
 <ul class="fa-ul mb-lg-4 mb-0 p-0">
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Green Grams</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Sweet Potato</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Ground Nut</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Cashew Nut</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">African Bird Eye Chilli     </a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Passion</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Honey</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Beef</a></li>
</ul>
</div>


<div class="col-lg-3">
    <h4 class="footer-header"></h4><br>

<ul class="fa-ul mb-lg-4 mb-0 p-0">
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Camel Milk</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Irish Potato</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Mango</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">French Beans</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Rice</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Vegetable</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Water Melon</a></li>
<li><i class="fa fa-fw fa-angle-right"></i> <a href="#">Cotton</a></li>
</ul>
</div>

</div>

</div>

</div>
        

<!-- BEGIN #footer-copyright -->
        <div id="footer-copyright" class="footer-copyright">
            <!-- BEGIN container -->
            <div class="container">
                
                <div class="copyright">
                    Copyright &copy; <?=date('Y')?> Agricultural Sector Development Support Programme (ASDSP II). All rights reserved.
                </div>
            </div>
            <!-- END container -->
        </div>
        <!-- END #footer-copyright -->